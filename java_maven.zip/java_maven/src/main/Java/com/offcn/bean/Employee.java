package com.offcn.bean;

import java.io.Serializable;
import java.util.Date;

public class Employee implements Serializable {

    private static final long serialVersionUID = 8368439287561912400L;
    private  Integer eid;
    private  String ename;
    private  String esex;
    private  Integer eage;
    private  String telephone;
    private Date hiredate;
    private String pnum;
    private String username;
    private String password;
    private String remark;
    private Integer pFk;
    private Integer dFk;
    private Integer lFk;
    private String emppic;

    public Integer getEid() {
        return eid;
    }

    public void setEid(Integer eid) {
        this.eid = eid;
    }
}
