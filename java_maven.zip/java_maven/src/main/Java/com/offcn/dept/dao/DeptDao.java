package com.offcn.dept.dao;

import com.offcn.bean.Dept;

import java.util.List;

public interface DeptDao {

    public List<Dept> selectDeptList();
}
