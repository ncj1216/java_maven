package com.offcn.dept.service;

import com.offcn.bean.Dept;

import java.util.List;

public interface DeptService {
    List<Dept> queryDeptList();
}
