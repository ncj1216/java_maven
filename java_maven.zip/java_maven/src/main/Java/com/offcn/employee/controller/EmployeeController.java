package com.offcn.employee.controller;

import com.offcn.bean.Employee;
import com.offcn.employee.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    private EmployeeService s;

    @RequestMapping("/project-add-employee-show")
    @ResponseBody
    public ResponseEntity<List<Employee>> projectionAddEmployeeShow(){

        List<Employee> ee=s.queryEmployeeListLimit(20);
        return ResponseEntity.ok(ee);
    }





}
