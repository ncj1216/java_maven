package com.offcn.employee.service;

import com.offcn.bean.Employee;
import com.offcn.employee.dao.EmployeeDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeDao dao;


    @Override
    public List<Employee> queryEmployeeListLimit(int num) {

        return dao.selectEmployeeListLimit(num);
    }
}
