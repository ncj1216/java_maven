package com.offcn.project.dao;

import com.offcn.bean.Project;
import com.offcn.bean.ProjectExtends;

import java.util.List;

public interface ProjectBaseDao {
    List<ProjectExtends> selectProjectList();


    void insert(Project project);
}
