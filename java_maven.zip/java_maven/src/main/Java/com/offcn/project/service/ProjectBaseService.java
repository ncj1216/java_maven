package com.offcn.project.service;

import com.github.pagehelper.PageInfo;
import com.offcn.bean.Project;
import com.offcn.bean.ProjectExtends;

public interface ProjectBaseService {
    PageInfo<ProjectExtends> queryProjectList(int currentPage);

    void save(Project project);
}
